package com.example.epap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
